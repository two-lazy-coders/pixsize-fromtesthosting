<!DOCTYPE html>
<html>
	<head>
		<title>Visual Sprite Cutter</title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="./assets/css/w3.css">		
		<link rel="stylesheet" href="./assets/css/style.css">
	</head>
<body class="w3-white">